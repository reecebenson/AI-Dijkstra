var worlds_8h =
[
    [ "CLOSED", "worlds_8h.html#ad6664b6aa0b2ec18771fe01aefa1e760", null ],
    [ "ENDX", "worlds_8h.html#ad55588a3f3c4ab37a0098072f6414a12", null ],
    [ "ENDY", "worlds_8h.html#aa8a1b4147c25510d931fdb91ca9e3c5a", null ],
    [ "MAXX", "worlds_8h.html#a7bb5845dcf8072f09f0a8d246b47e032", null ],
    [ "MAXY", "worlds_8h.html#a25602e1c79852e5be195490eceff513f", null ],
    [ "MINX", "worlds_8h.html#a839abfdf7681b95890fa796edf406b24", null ],
    [ "MINY", "worlds_8h.html#a2366b41580ffedc36a6153dda0bd7226", null ],
    [ "OBSTACLE", "worlds_8h.html#af2ea9daadfc38f4b5b104224552aabcb", null ],
    [ "OCCUPIED", "worlds_8h.html#a217ad8485de2dcca79110f37d4da9688", null ],
    [ "OPEN", "worlds_8h.html#a1354b70ac6803a06beebe84f61b5f95b", null ],
    [ "STARTX", "worlds_8h.html#a6ffc62811b3e92f8acbedcec612c8030", null ],
    [ "STARTY", "worlds_8h.html#afa7f69258876ee4ca4c4f9ee3cafffd4", null ],
    [ "CopyMap", "worlds_8h.html#ae48dfacd9fc59b0255457a233ed616fb", null ],
    [ "PrintMap", "worlds_8h.html#a390ce6f149bb44e21dd77a756c6e7ced", null ],
    [ "ReadComandLineAndSetMap", "worlds_8h.html#a3c8d948e2c4496a6053161fc75a070e5", null ]
];