var _path_finding_specific_definitions_8h =
[
    [ "BIGDIST", "_path_finding_specific_definitions_8h.html#a12fa5c1723dc167c0aaea4cf3e25a576", null ],
    [ "N", "_path_finding_specific_definitions_8h.html#a0240ac851181b84ac374872dc5434ee4", null ],
    [ "PARENTXCOORD", "_path_finding_specific_definitions_8h.html#a0629dc9499c0ded99aca1639a423e7e4", null ],
    [ "PARENTYCOORD", "_path_finding_specific_definitions_8h.html#a446e892ff1bc0bbc6cf00f14bc4f743f", null ],
    [ "SIZEOFSOLUTIONLIST", "_path_finding_specific_definitions_8h.html#aee7795481de30f64d6f5e10b43842e97", null ],
    [ "SQEUCLIDEAN_DISTANCE", "_path_finding_specific_definitions_8h.html#acc3d5be8079dca5f511b80ff2cbfca21", null ],
    [ "UNUSED", "_path_finding_specific_definitions_8h.html#addf5ec070e9499d36b7f2009ce736076", null ],
    [ "XCOORD", "_path_finding_specific_definitions_8h.html#ae85be36b0d52d74fa2a9f0cf0e2dabfb", null ],
    [ "YCOORD", "_path_finding_specific_definitions_8h.html#a03d7b1afc77e19b3279d170140eac1cf", null ]
];