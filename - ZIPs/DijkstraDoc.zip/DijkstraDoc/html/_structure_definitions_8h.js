var _structure_definitions_8h =
[
    [ "candidateSolution", "structcandidate_solution.html", "structcandidate_solution" ],
    [ "candidateList", "structcandidate_list.html", "structcandidate_list" ],
    [ "Generic_StructureDefinitions_h", "_structure_definitions_8h.html#a5d0e01e65cd7f14a92033a35fd995ce2", null ],
    [ "NOTFOUND", "_structure_definitions_8h.html#ad96490cc68537c8d1797ed2a62489836", null ]
];