var structcandidate_list =
[
    [ "indexOfLastEntryAdded", "structcandidate_list.html#a8d34bc217c2cbfdcda7b18912791762c", null ],
    [ "listEntries", "structcandidate_list.html#a8c423a6f6f50a8358ef8810e3307a101", null ]
];