var searchData=
[
  ['numberofcellsvisited',['numberOfCellsVisited',['../_path_finding_specific_solution_operations_8h.html#a447db1b70220141bbf7ee6bb4c7c0a35',1,'PathFindingSpecificSolutionOperations.h']]],
  ['numberofdefinedvalues',['numberOfDefinedValues',['../structcandidate_solution.html#aa8031610c543386d706ee7bc50b1d835',1,'candidateSolution']]]
];
