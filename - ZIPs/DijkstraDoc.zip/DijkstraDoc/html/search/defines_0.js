var searchData=
[
  ['closed',['CLOSED',['../worlds_8h.html#ad6664b6aa0b2ec18771fe01aefa1e760',1,'worlds.h']]]
];
