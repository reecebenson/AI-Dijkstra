var searchData=
[
  ['candidatelist',['candidateList',['../structcandidate_list.html',1,'']]],
  ['candidatesolution',['candidateSolution',['../structcandidate_solution.html',1,'']]]
];
