var searchData=
[
  ['listentries',['listEntries',['../structcandidate_list.html#a8c423a6f6f50a8358ef8810e3307a101',1,'candidateList']]]
];
