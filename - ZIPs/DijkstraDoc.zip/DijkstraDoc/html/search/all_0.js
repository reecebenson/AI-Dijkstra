var searchData=
[
  ['addsolutionpram1_5ftolistparam2',['AddSolutionPram1_ToListParam2',['../_solution_list_operations_8h.html#aab9de6fd249c08a9e8082afbc0a361d3',1,'SolutionListOperations.c']]],
  ['addworkingcandidatetocurrentlist',['AddWorkingCandidateToCurrentList',['../_solution_list_operations_8h.html#aa6d63cb9d1084f94d369de7b63d754f1',1,'SolutionListOperations.c']]],
  ['addworkingcandidatetoexaminedlist',['AddWorkingCandidateToExaminedList',['../_solution_list_operations_8h.html#ab4eb8569e9e0ae5beac37067ead564c6',1,'SolutionListOperations.c']]]
];
