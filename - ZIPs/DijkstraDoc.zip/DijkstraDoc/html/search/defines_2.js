var searchData=
[
  ['solutionlistoperations_5fh',['SolutionListOperations_h',['../_solution_list_operations_8h.html#a9bb35aee8771665fed73c4cc06273b26',1,'SolutionListOperations.h']]]
];
