var searchData=
[
  ['extendworkingcandidatebyaddingvalue',['ExtendWorkingCandidateByAddingValue',['../_solution_list_operations_8h.html#a772d5dadc98a4fbe52e53bd723812738',1,'SolutionListOperations.c']]]
];
